package com.xplayer.app.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("xplayer", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val favType = object : TypeToken<List<Fav>>() {}.type

    fun save(l: Login) {
        val e = sp.edit()
        when (l) {
            is Login.Xtream -> e.putString("mode", "x")
                .putString("server", l.cred.server)
                .putString("user", l.cred.username)
                .putString("pass", l.cred.password)
            is Login.M3u -> e.putString("mode", "m").putString("m3u", l.url)
        }
        e.apply()
    }

    fun load(): Login? {
        val mode = sp.getString("mode", null)
        if (mode == "m") return sp.getString("m3u", null)?.let { Login.M3u(it) }
        val s = sp.getString("server", null) ?: return null
        val u = sp.getString("user", null) ?: return null
        val p = sp.getString("pass", null) ?: return null
        return Login.Xtream(Credentials(s, u, p))
    }

    fun clear() = sp.edit().clear().apply()

    fun loadFavs(): List<Fav> = read("favs")
    fun saveFavs(l: List<Fav>) = sp.edit().putString("favs", gson.toJson(l)).apply()
    fun loadRecents(): List<Fav> = read("recents")
    fun saveRecents(l: List<Fav>) = sp.edit().putString("recents", gson.toJson(l)).apply()

    private fun read(key: String): List<Fav> = try {
        val json = sp.getString(key, null)
        if (json == null) emptyList() else gson.fromJson<List<Fav>>(json, favType) ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }
}
