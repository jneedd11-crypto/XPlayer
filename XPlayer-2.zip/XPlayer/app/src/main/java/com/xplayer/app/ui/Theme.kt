package com.xplayer.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

val Accent = Color(0xFF29D3C0)
val Violet = Color(0xFF7C5CFF)
val BgTop = Color(0xFF151728)
val BgBottom = Color(0xFF0B0C12)

private val DarkColors = darkColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    secondary = Accent,
    background = Color(0xFF0E0F14),
    onBackground = Color(0xFFECEDF3),
    surface = Color(0xFF171923),
    onSurface = Color(0xFFECEDF3),
    surfaceVariant = Color(0xFF222534),
    onSurfaceVariant = Color(0xFFB4B7C7),
    error = Color(0xFFFF6B6B),
)

@Composable
fun XTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}

/** Highlights an item when it has D-pad / keyboard focus (TV box remotes). Put it before clickable. */
fun Modifier.tvFocus(shape: Shape = RoundedCornerShape(12.dp)): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.04f else 1f, label = "focusScale")
    this
        .onFocusChanged { focused = it.hasFocus }
        .scale(scale)
        .border(if (focused) 3.dp else 0.dp, if (focused) Accent else Color.Transparent, shape)
}
