@file:OptIn(UnstableApi::class)

package com.xplayer.app.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.xplayer.app.MainViewModel
import com.xplayer.app.R
import com.xplayer.app.data.Entry
import com.xplayer.app.data.PlayRequest
import com.xplayer.app.data.Tab
import com.xplayer.app.data.sameAs
import kotlinx.coroutines.delay

/**
 * Full-screen player.
 *
 * Live TV: Up/Down (or CH+/CH-) switch channel, Left/Right/Menu open the channel list,
 * OK shows the controls (previous / play / next / channel list).
 * Movies & episodes: Left/Right seek 10s, OK play/pause.
 */
@Composable
fun PlayerScreen(vm: MainViewModel, req: PlayRequest, onClose: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity

    var failed by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(true) }
    var overlay by remember { mutableStateOf(true) }
    var panel by remember { mutableStateOf(false) }
    var vodControls by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var viewRef by remember { mutableStateOf<PlayerView?>(null) }
    val rootFocus = remember { FocusRequester() }
    val playFocus = remember { FocusRequester() }

    val exo = remember {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("XPlayer/1.0")
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(context).setDataSourceFactory(http))
            .build()
            .apply { playWhenReady = true }
    }

    // Load (or switch to) the requested stream; the same player is reused so zapping is fast.
    LaunchedEffect(req.url) {
        failed = false
        exo.setMediaItem(MediaItem.fromUri(req.url))
        exo.prepare()
        exo.playWhenReady = true
    }

    LaunchedEffect(req.live) {
        if (req.live) vm.ensureLoaded(Tab.LIVE)
    }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                failed = true
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) failed = false
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) exo.pause()
        }
        val owner = context as? LifecycleOwner
        exo.addListener(listener)
        owner?.lifecycle?.addObserver(observer)
        onDispose {
            owner?.lifecycle?.removeObserver(observer)
            exo.removeListener(listener)
            exo.release()
        }
    }

    // Landscape + immersive + keep screen on
    DisposableEffect(Unit) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            controller?.show(WindowInsetsCompat.Type.systemBars())
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Live controls hide by themselves after 5 seconds of no interaction.
    LaunchedEffect(overlay, tick, panel, req.live) {
        if (req.live && overlay && !panel) {
            delay(5000)
            overlay = false
        }
    }

    // Keep keyboard / remote focus in the right place.
    LaunchedEffect(overlay, panel, req.live) {
        delay(60)
        if (!panel) {
            runCatching {
                if (req.live && overlay) playFocus.requestFocus() else rootFocus.requestFocus()
            }
        }
    }

    BackHandler {
        if (panel) panel = false else onClose()
    }

    fun togglePlay() {
        if (exo.isPlaying) exo.pause() else exo.play()
    }

    fun onKey(ev: KeyEvent): Boolean {
        if (ev.type != KeyEventType.KeyDown) return false
        tick++
        if (panel) return false
        val k = ev.key
        if (req.live) {
            return when (k) {
                Key.DirectionUp, Key.ChannelUp -> {
                    vm.zap(-1); overlay = true; true
                }
                Key.DirectionDown, Key.ChannelDown -> {
                    vm.zap(1); overlay = true; true
                }
                Key.DirectionLeft, Key.DirectionRight ->
                    if (overlay) false else {
                        panel = true; true
                    }
                Key.Menu -> {
                    panel = true; true
                }
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter ->
                    if (overlay) false else {
                        overlay = true; true
                    }
                Key.MediaPlayPause -> {
                    togglePlay(); true
                }
                else -> false
            }
        }
        viewRef?.showController()
        return when (k) {
            Key.DirectionLeft -> {
                exo.seekTo((exo.currentPosition - 10_000).coerceAtLeast(0)); true
            }
            Key.DirectionRight -> {
                exo.seekTo(exo.currentPosition + 10_000); true
            }
            Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause -> {
                togglePlay(); true
            }
            else -> false
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent { onKey(it) }
            .focusRequester(rootFocus)
            .focusable()
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exo
                    useController = !req.live
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                    isFocusable = false
                    descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                    setControllerVisibilityListener(
                        PlayerView.ControllerVisibilityListener { visibility ->
                            vodControls = visibility == View.VISIBLE
                        }
                    )
                    viewRef = this
                }
            },
            update = {
                it.player = exo
                it.useController = !req.live
            },
        )

        // Tap anywhere on live video to show / hide the controls.
        if (req.live) {
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(onTap = { overlay = !overlay })
                    }
            )
        }

        // Title bar
        AnimatedVisibility(
            visible = if (req.live) overlay else vodControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.75f), Color.Transparent)))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose, modifier = Modifier.tvFocus(CircleShape)) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = Color.White,
                    )
                }
                Text(
                    req.title,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 4.dp),
                )
                if (req.live && req.queue.size > 1) {
                    Text(
                        "${req.index + 1} / ${req.queue.size}",
                        color = Color.White.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(end = 12.dp),
                    )
                }
            }
        }

        // Live controls: previous / play-pause / next / channel list
        if (req.live) {
            AnimatedVisibility(
                visible = overlay && !panel,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter),
            ) {
                Row(
                    Modifier.padding(bottom = 28.dp),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ControlButton(Icons.Default.SkipPrevious, stringResource(R.string.prev_channel)) { vm.zap(-1) }
                    ControlButton(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        stringResource(R.string.play_pause),
                        Modifier.focusRequester(playFocus),
                    ) { togglePlay() }
                    ControlButton(Icons.Default.SkipNext, stringResource(R.string.next_channel)) { vm.zap(1) }
                    ControlButton(Icons.AutoMirrored.Filled.List, stringResource(R.string.channels)) { panel = true }
                }
            }

            // Channel list panel
            AnimatedVisibility(
                visible = panel,
                enter = slideInHorizontally { it },
                exit = slideOutHorizontally { it },
                modifier = Modifier.align(Alignment.CenterEnd),
            ) {
                ChannelPanel(vm, req) { e, list ->
                    vm.play(Tab.LIVE, e, list)
                    panel = false
                }
            }
        }

        if (failed) {
            Column(
                Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(stringResource(R.string.error_play), color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        failed = false
                        exo.prepare()
                        exo.play()
                    },
                    modifier = Modifier.tvFocus(),
                ) { Text(stringResource(R.string.retry)) }
            }
        }
    }
}

@Composable
private fun ControlButton(
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(56.dp)
            .tvFocus(CircleShape)
            .background(Color.Black.copy(alpha = 0.55f), CircleShape),
    ) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size(30.dp))
    }
}

@Composable
private fun ChannelPanel(
    vm: MainViewModel,
    req: PlayRequest,
    onPick: (Entry, List<Entry>) -> Unit,
) {
    val current = req.queue.getOrNull(req.index)
    var cat by remember { mutableStateOf(current?.categoryId) }
    val loaded = vm.entriesFor(Tab.LIVE)
    val base = if (loaded.isEmpty()) req.queue else loaded
    val list = remember(base, cat) {
        if (cat == null) base else base.filter { it.categoryId == cat }
    }
    val state = rememberLazyListState()

    LaunchedEffect(list) {
        val i = list.indexOfFirst { current != null && it.sameAs(current) }
        if (i >= 0) state.scrollToItem(i)
    }

    Surface(
        modifier = Modifier
            .width(340.dp)
            .fillMaxHeight(),
        color = Color(0xF2171923),
    ) {
        Column {
            Text(
                stringResource(R.string.channels),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp),
            )
            val cats = vm.categories.takeIf { vm.tab == Tab.LIVE } ?: emptyList()
            if (cats.isNotEmpty()) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item {
                        FilterChip(
                            selected = cat == null,
                            onClick = { cat = null },
                            label = { Text(stringResource(R.string.all)) },
                            modifier = Modifier.tvFocus(),
                        )
                    }
                    items(cats) { c ->
                        FilterChip(
                            selected = cat == c.category_id,
                            onClick = { cat = c.category_id },
                            label = { Text(c.category_name.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            modifier = Modifier.tvFocus(),
                        )
                    }
                }
            }
            LazyColumn(
                state = state,
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(list) { e ->
                    val isCurrent = current != null && e.sameAs(current)
                    PanelRow(e, isCurrent) { onPick(e, list) }
                }
            }
        }
    }
}

@Composable
private fun PanelRow(e: Entry, current: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (current) runCatching { focus.requestFocus() }
    }
    Surface(
        shape = shape,
        color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .focusRequester(focus)
            .tvFocus(shape)
            .clip(shape)
            .clickable(onClick = onClick),
    ) {
        Text(
            e.name,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
        )
    }
}
