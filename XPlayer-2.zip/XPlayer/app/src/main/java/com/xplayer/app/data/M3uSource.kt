package com.xplayer.app.data

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Plays a plain M3U / M3U8 playlist, sorting entries into live, movies and series. */
class M3uSource(private val link: String) : Source {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    private val lock = Mutex()
    private var parsed: Map<Tab, List<Entry>>? = null

    override val hasSeriesDetail = false

    /** Downloads and parses the playlist once. Throws when it cannot be read or is empty. */
    suspend fun ensureLoaded(): Map<Tab, List<Entry>> = lock.withLock {
        parsed ?: withContext(Dispatchers.IO) { download() }.also { parsed = it }
    }

    private fun download(): Map<Tab, List<Entry>> {
        val req = Request.Builder().url(link).header("User-Agent", "XPlayer/1.0").build()
        val result = http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("HTTP ${resp.code}")
            val body = resp.body ?: error("empty body")
            body.byteStream().bufferedReader().useLines { parse(it) }
        }
        if (result.values.all { it.isEmpty() }) error("no entries")
        return result
    }

    override suspend fun categories(tab: Tab): List<Category> =
        ensureLoaded()[tab].orEmpty()
            .mapNotNull { it.categoryId }
            .distinct()
            .map { Category(it, it) }

    override suspend fun entries(tab: Tab): List<Entry> = ensureLoaded()[tab].orEmpty()

    override suspend fun seriesInfo(entry: Entry): SeriesDetail =
        error("M3U series have no episode list")

    override fun playUrl(tab: Tab, e: Entry): String = e.url.orEmpty()

    override fun episodeUrl(ep: Episode): String = ""

    companion object {
        private val attrRe = Regex("""([\w-]+)="([^"]*)"""")
        private const val OTHER = "Other"

        private val movieWords = listOf("movie", "movies", "vod", "film", "films", "cinema", "فيلم", "افلام", "أفلام")
        private val seriesWords = listOf("series", "serie", "show", "shows", "season", "مسلسل", "مسلسلات")
        private val videoExt = listOf(".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv")

        fun parse(lines: Sequence<String>): Map<Tab, List<Entry>> {
            val out = mapOf(
                Tab.LIVE to mutableListOf<Entry>(),
                Tab.MOVIES to mutableListOf(),
                Tab.SERIES to mutableListOf(),
            )
            var name: String? = null
            var logo: String? = null
            var group: String? = null
            var counter = 0

            for (raw in lines) {
                val line = raw.trim()
                if (line.isEmpty()) continue
                if (line.startsWith("#EXTINF", ignoreCase = true)) {
                    val attrs = attrRe.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    val q = line.lastIndexOf('"')
                    val comma = line.indexOf(',', if (q >= 0) q else 0)
                    val title = if (comma >= 0) line.substring(comma + 1).trim() else ""
                    name = title.ifEmpty { attrs["tvg-name"].orEmpty() }
                    logo = attrs["tvg-logo"]?.ifBlank { null }
                    group = attrs["group-title"]?.ifBlank { null }
                } else if (line.startsWith("#")) {
                    continue
                } else if (name != null) {
                    val tab = classify(line, group)
                    out.getValue(tab) += Entry(
                        id = ++counter,
                        name = name.ifEmpty { "Channel $counter" },
                        image = logo,
                        categoryId = group ?: OTHER,
                        ext = null,
                        rating = null,
                        url = line,
                    )
                    name = null
                    logo = null
                    group = null
                }
            }
            return out
        }

        private fun classify(url: String, group: String?): Tab {
            val u = url.lowercase()
            if ("/series/" in u) return Tab.SERIES
            if ("/movie/" in u) return Tab.MOVIES
            val g = group?.lowercase().orEmpty()
            if (seriesWords.any { it in g }) return Tab.SERIES
            if (movieWords.any { it in g }) return Tab.MOVIES
            val path = u.substringBefore('?')
            if (videoExt.any { path.endsWith(it) }) return Tab.MOVIES
            return Tab.LIVE
        }

        /**
         * Xtream providers hand out M3U links like
         * http://host:port/get.php?username=U&password=P&type=m3u_plus.
         * Those are converted to a normal Xtream login (faster, and series work properly).
         */
        fun asXtream(link: String): Credentials? {
            return try {
                val uri = Uri.parse(link.trim())
                val user = uri.getQueryParameter("username")
                val pass = uri.getQueryParameter("password")
                val host = uri.host
                val isXtream = uri.path.orEmpty().endsWith("get.php") || uri.path.orEmpty().endsWith("player_api.php")
                if (!isXtream || user.isNullOrBlank() || pass.isNullOrBlank() || host.isNullOrBlank()) return null
                val scheme = uri.scheme ?: "http"
                val port = if (uri.port != -1) ":${uri.port}" else ""
                Credentials("$scheme://$host$port", user, pass)
            } catch (e: Exception) {
                null
            }
        }
    }
}
