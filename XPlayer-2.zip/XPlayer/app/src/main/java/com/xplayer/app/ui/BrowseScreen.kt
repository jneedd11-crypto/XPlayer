package com.xplayer.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.xplayer.app.MainViewModel
import com.xplayer.app.R
import com.xplayer.app.data.Entry
import com.xplayer.app.data.Tab

private fun tabLabel(t: Tab): Int = when (t) {
    Tab.LIVE -> R.string.tab_live
    Tab.MOVIES -> R.string.tab_movies
    Tab.SERIES -> R.string.tab_series
}

@Composable
fun BrowseScreen(vm: MainViewModel) {
    val tab = vm.tab
    val all = vm.allItems
    val categoryId = vm.categoryId
    val query = vm.query
    val items = remember(all, categoryId, query) {
        val q = query.trim()
        all.filter {
            (categoryId == null || it.categoryId == categoryId) &&
                (q.isEmpty() || it.name.contains(q, ignoreCase = true))
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
    ) {
        // Top bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BackButton { vm.goHome() }
            Text(
                stringResource(tabLabel(tab)),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 4.dp),
            )
            OutlinedTextField(
                value = query,
                onValueChange = { vm.query = it },
                singleLine = true,
                placeholder = { Text(stringResource(R.string.search)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.width(210.dp),
            )
        }

        BoxWithConstraints(Modifier.weight(1f)) {
            val wide = maxWidth >= 600.dp
            if (wide) {
                Row(Modifier.fillMaxSize()) {
                    if (vm.categories.isNotEmpty()) {
                        CategorySidebar(vm, Modifier.width(210.dp))
                    }
                    BrowseContent(vm, items, Modifier.weight(1f))
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    if (vm.categories.isNotEmpty()) {
                        CategoryChips(vm)
                    }
                    BrowseContent(vm, items, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun CategorySidebar(vm: MainViewModel, modifier: Modifier) {
    LazyColumn(
        modifier,
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        item {
            CategoryItem(stringResource(R.string.all), vm.categoryId == null) { vm.selectCategory(null) }
        }
        items(vm.categories) { c ->
            CategoryItem(c.category_name.orEmpty(), vm.categoryId == c.category_id) {
                vm.selectCategory(c.category_id)
            }
        }
    }
}

@Composable
private fun CategoryItem(name: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Surface(
        shape = shape,
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .tvFocus(shape)
            .clip(shape)
            .clickable(onClick = onClick),
    ) {
        Text(
            name,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
        )
    }
}

@Composable
private fun CategoryChips(vm: MainViewModel) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            FilterChip(
                selected = vm.categoryId == null,
                onClick = { vm.selectCategory(null) },
                label = { Text(stringResource(R.string.all)) },
                modifier = Modifier.tvFocus(),
            )
        }
        items(vm.categories) { c ->
            FilterChip(
                selected = vm.categoryId == c.category_id,
                onClick = { vm.selectCategory(c.category_id) },
                label = { Text(c.category_name.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                modifier = Modifier.tvFocus(),
            )
        }
    }
}

@Composable
private fun BrowseContent(vm: MainViewModel, items: List<Entry>, modifier: Modifier) {
    val tab = vm.tab
    Box(modifier.fillMaxSize()) {
        when {
            vm.loading && vm.allItems.isEmpty() ->
                CircularProgressIndicator(Modifier.align(Alignment.Center))

            vm.failed && vm.allItems.isEmpty() ->
                Column(
                    Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(stringResource(R.string.error_load), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { vm.retry() }, modifier = Modifier.tvFocus()) {
                        Text(stringResource(R.string.retry))
                    }
                }

            items.isEmpty() ->
                Text(
                    stringResource(R.string.empty),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center),
                )

            tab == Tab.LIVE ->
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(items) { e ->
                        ChannelRow(
                            e = e,
                            fav = vm.isFav(tab, e),
                            onFav = { vm.toggleFav(tab, e) },
                            onClick = { vm.play(tab, e, items) },
                        )
                    }
                }

            else ->
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(116.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(items) { e ->
                        PosterCard(
                            e = e,
                            fav = vm.isFav(tab, e),
                            onLongClick = { vm.toggleFav(tab, e) },
                            onClick = { vm.play(tab, e) },
                        )
                    }
                }
        }

        if (vm.seriesLoading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
    }
}
