package com.xplayer.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.xplayer.app.MainViewModel
import com.xplayer.app.R
import com.xplayer.app.data.Tab

@Composable
fun FavoritesScreen(vm: MainViewModel) {
    var tab by remember { mutableStateOf(Tab.LIVE) }
    val list = vm.favorites.filter { it.tab == tab }.map { it.entry }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BackButton { vm.goHome() }
            Text(
                stringResource(R.string.home_favorites),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp),
            )
        }

        Row(
            Modifier.padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(
                Tab.LIVE to R.string.tab_live,
                Tab.MOVIES to R.string.tab_movies,
                Tab.SERIES to R.string.tab_series,
            ).forEach { (t, label) ->
                FilterChip(
                    selected = tab == t,
                    onClick = { tab = t },
                    label = { Text(stringResource(label)) },
                    modifier = Modifier.tvFocus(),
                )
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                list.isEmpty() -> Text(
                    stringResource(R.string.favorites_empty) + "\n" + stringResource(R.string.hint_fav),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                )

                tab == Tab.LIVE -> LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(list) { e ->
                        ChannelRow(
                            e = e,
                            fav = true,
                            onFav = { vm.toggleFav(tab, e) },
                            onClick = { vm.play(tab, e, list) },
                        )
                    }
                }

                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(116.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(list) { e ->
                        PosterCard(
                            e = e,
                            fav = true,
                            onLongClick = { vm.toggleFav(tab, e) },
                            onClick = { vm.play(tab, e) },
                        )
                    }
                }
            }
        }
    }
}
