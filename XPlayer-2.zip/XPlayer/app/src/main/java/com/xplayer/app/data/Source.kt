package com.xplayer.app.data

/** A provider of channels / movies / series: either an Xtream server or an M3U playlist. */
interface Source {
    /** True when series have an episode list (Xtream). M3U series entries play directly. */
    val hasSeriesDetail: Boolean

    suspend fun categories(tab: Tab): List<Category>
    suspend fun entries(tab: Tab): List<Entry>
    suspend fun seriesInfo(entry: Entry): SeriesDetail

    fun playUrl(tab: Tab, e: Entry): String
    fun episodeUrl(ep: Episode): String
}
