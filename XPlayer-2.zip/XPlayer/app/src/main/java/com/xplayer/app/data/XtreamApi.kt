package com.xplayer.app.data

import com.google.gson.JsonObject
import retrofit2.http.GET
import retrofit2.http.Query

interface XtreamApi {

    @GET("player_api.php")
    suspend fun auth(
        @Query("username") username: String,
        @Query("password") password: String,
    ): AuthResponse

    @GET("player_api.php")
    suspend fun categories(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String,
    ): List<Category>

    @GET("player_api.php")
    suspend fun live(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String,
    ): List<LiveStream>

    @GET("player_api.php")
    suspend fun vod(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String,
    ): List<VodStream>

    @GET("player_api.php")
    suspend fun series(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String,
    ): List<SeriesItem>

    @GET("player_api.php")
    suspend fun seriesInfo(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String,
        @Query("series_id") seriesId: Int,
    ): JsonObject
}
