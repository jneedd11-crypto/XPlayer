package com.xplayer.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.xplayer.app.MainViewModel
import com.xplayer.app.R
import com.xplayer.app.data.Tab

private class TileSpec(
    val label: Int,
    val icon: ImageVector,
    val colors: List<Color>,
    val action: () -> Unit,
)

@Composable
fun HomeScreen(vm: MainViewModel) {
    val tiles = listOf(
        TileSpec(R.string.tab_live, Icons.Default.Tv, listOf(Color(0xFF7C5CFF), Color(0xFF4F3BD6))) { vm.openTab(Tab.LIVE) },
        TileSpec(R.string.tab_movies, Icons.Default.Movie, listOf(Color(0xFF29D3C0), Color(0xFF14998A))) { vm.openTab(Tab.MOVIES) },
        TileSpec(R.string.tab_series, Icons.Default.VideoLibrary, listOf(Color(0xFFFF8A4C), Color(0xFFD9562A))) { vm.openTab(Tab.SERIES) },
        TileSpec(R.string.home_favorites, Icons.Default.Star, listOf(Color(0xFFEC5C9B), Color(0xFFB83373))) { vm.openFavorites() },
    )

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, BgBottom)))
    ) {
        val wide = maxWidth >= 700.dp
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            // Header
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = Accent,
                    modifier = Modifier.weight(1f),
                )
                vm.account?.let { acc ->
                    Text(
                        text = acc.expiry?.let { stringResource(R.string.expires_fmt, it) }
                            ?: stringResource(R.string.no_expiry),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = { vm.openSettings() }, modifier = Modifier.tvFocus(CircleShape)) {
                    Icon(Icons.Default.Settings, contentDescription = stringResource(R.string.home_settings))
                }
            }
            Spacer(Modifier.height(20.dp))

            // Tiles
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    tiles.forEach { HomeTile(it, 170.dp, Modifier.weight(1f)) }
                }
            } else {
                tiles.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        pair.forEach { HomeTile(it, 120.dp, Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }

            // Recently watched
            if (vm.recents.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Text(
                    stringResource(R.string.continue_watching),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(vm.recents.toList()) { f ->
                        PosterCard(
                            e = f.entry,
                            fav = vm.isFav(f.tab, f.entry),
                            modifier = Modifier.width(120.dp),
                            onLongClick = { vm.toggleFav(f.tab, f.entry) },
                            onClick = { vm.play(f.tab, f.entry, vm.queueFor(f)) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTile(spec: TileSpec, height: androidx.compose.ui.unit.Dp, modifier: Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .height(height)
            .tvFocus(shape)
            .clip(shape)
            .background(Brush.linearGradient(spec.colors))
            .clickable(onClick = spec.action)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(spec.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(spec.label),
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
