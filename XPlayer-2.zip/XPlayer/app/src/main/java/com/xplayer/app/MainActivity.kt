package com.xplayer.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.xplayer.app.data.Screen
import com.xplayer.app.ui.BrowseScreen
import com.xplayer.app.ui.FavoritesScreen
import com.xplayer.app.ui.HomeScreen
import com.xplayer.app.ui.LoginScreen
import com.xplayer.app.ui.PlayerScreen
import com.xplayer.app.ui.SeriesScreen
import com.xplayer.app.ui.SettingsScreen
import com.xplayer.app.ui.XTheme

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            XTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(vm)
                }
            }
        }
    }
}

@Composable
private fun App(vm: MainViewModel) {
    val context = LocalContext.current
    vm.message?.let { res ->
        LaunchedEffect(res) {
            Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
            vm.message = null
        }
    }

    val playing = vm.playing
    val series = vm.seriesDetail

    // Back from a sub-screen returns to the home screen (the player and series pages handle their own back).
    BackHandler(enabled = vm.source != null && playing == null && series == null && vm.screen != Screen.HOME) {
        vm.goHome()
    }

    when {
        vm.source == null -> LoginScreen(vm)
        playing != null -> PlayerScreen(vm, playing, onClose = { vm.playing = null })
        series != null -> SeriesScreen(vm, series)
        else -> when (vm.screen) {
            Screen.HOME -> HomeScreen(vm)
            Screen.BROWSE -> BrowseScreen(vm)
            Screen.FAVORITES -> FavoritesScreen(vm)
            Screen.SETTINGS -> SettingsScreen(vm)
        }
    }
}
