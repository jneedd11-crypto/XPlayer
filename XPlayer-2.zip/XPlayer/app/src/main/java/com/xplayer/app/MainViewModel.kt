package com.xplayer.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xplayer.app.data.AccountInfo
import com.xplayer.app.data.AuthResponse
import com.xplayer.app.data.Category
import com.xplayer.app.data.Credentials
import com.xplayer.app.data.Entry
import com.xplayer.app.data.Episode
import com.xplayer.app.data.Fav
import com.xplayer.app.data.Login
import com.xplayer.app.data.M3uSource
import com.xplayer.app.data.PlayRequest
import com.xplayer.app.data.Prefs
import com.xplayer.app.data.Screen
import com.xplayer.app.data.SeriesDetail
import com.xplayer.app.data.Source
import com.xplayer.app.data.Tab
import com.xplayer.app.data.XtreamRepository
import com.xplayer.app.data.sameAs
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)

    var source by mutableStateOf<Source?>(null)
        private set
    var account by mutableStateOf<AccountInfo?>(null)
        private set
    var screen by mutableStateOf(Screen.HOME)
        private set

    // Login
    var loginLoading by mutableStateOf(false)
        private set
    var loginError by mutableStateOf<Int?>(null)
        private set

    // Browse
    var tab by mutableStateOf(Tab.LIVE)
        private set
    var categoryId by mutableStateOf<String?>(null)
        private set
    var query by mutableStateOf("")

    private val cats = mutableStateMapOf<Tab, List<Category>>()
    private val data = mutableStateMapOf<Tab, List<Entry>>()
    private val loadingTabs = mutableStateMapOf<Tab, Boolean>()
    private val failedTabs = mutableStateMapOf<Tab, Boolean>()

    val favorites = mutableStateListOf<Fav>()
    val recents = mutableStateListOf<Fav>()

    val categories: List<Category> get() = cats[tab].orEmpty()
    val allItems: List<Entry> get() = data[tab].orEmpty()
    val loading: Boolean get() = loadingTabs[tab] == true
    val failed: Boolean get() = failedTabs[tab] == true

    fun entriesFor(t: Tab): List<Entry> = data[t].orEmpty()

    fun categoriesFor(t: Tab): List<Category> = cats[t].orEmpty()

    // Playback / series
    var playing by mutableStateOf<PlayRequest?>(null)
    var seriesDetail by mutableStateOf<SeriesDetail?>(null)
        private set
    var seriesLoading by mutableStateOf(false)
        private set
    var message by mutableStateOf<Int?>(null)

    init {
        prefs.load()?.let { openSession(it) }
    }

    // ---------- Login ----------

    private fun startLogin(block: suspend () -> Unit) {
        viewModelScope.launch {
            loginLoading = true
            loginError = null
            try {
                block()
            } catch (e: Exception) {
                loginError = R.string.error_connect
            }
            loginLoading = false
        }
    }

    fun login(server: String, user: String, pass: String) {
        if (server.isBlank() || user.isBlank() || pass.isBlank()) {
            loginError = R.string.error_fields
            return
        }
        startLogin {
            val cred = Credentials(server.trim(), user.trim(), pass.trim())
            val res = XtreamRepository(cred).authenticate()
            if (res.user_info?.auth == "1") {
                val l = Login.Xtream(cred)
                prefs.save(l)
                openSession(l, res)
            } else {
                loginError = R.string.error_auth
            }
        }
    }

    fun loginM3u(link: String) {
        val l = link.trim()
        if (l.isEmpty()) {
            loginError = R.string.error_fields
            return
        }
        // Xtream-style M3U links become a normal (faster) Xtream login.
        val x = M3uSource.asXtream(l)
        if (x != null) {
            login(x.server, x.username, x.password)
            return
        }
        startLogin {
            val s = M3uSource(l)
            try {
                s.ensureLoaded()
            } catch (e: Exception) {
                loginError = R.string.error_m3u
                return@startLogin
            }
            val login = Login.M3u(l)
            prefs.save(login)
            openSession(login, null, s)
        }
    }

    private fun openSession(login: Login, res: AuthResponse? = null, src: Source? = null) {
        val s = src ?: when (login) {
            is Login.Xtream -> XtreamRepository(login.cred)
            is Login.M3u -> M3uSource(login.url)
        }
        source = s
        if (login is Login.Xtream && s is XtreamRepository) {
            if (res != null) {
                account = toAccount(login.cred, res)
            } else {
                viewModelScope.launch {
                    try {
                        account = toAccount(login.cred, s.authenticate())
                    } catch (e: Exception) {
                        // offline: the app still works with cached login
                    }
                }
            }
        }
        favorites.clear()
        favorites.addAll(prefs.loadFavs())
        recents.clear()
        recents.addAll(prefs.loadRecents())
        screen = Screen.HOME
    }

    private fun toAccount(c: Credentials, r: AuthResponse): AccountInfo {
        val ui = r.user_info
        val exp = ui?.exp_date?.toLongOrNull()
            ?.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it * 1000)) }
        return AccountInfo(c.username, c.server, ui?.status, exp, ui?.max_connections)
    }

    fun logout() {
        prefs.clear()
        source = null
        account = null
        cats.clear()
        data.clear()
        loadingTabs.clear()
        failedTabs.clear()
        favorites.clear()
        recents.clear()
        playing = null
        seriesDetail = null
        tab = Tab.LIVE
        categoryId = null
        query = ""
        screen = Screen.HOME
    }

    // ---------- Navigation ----------

    fun goHome() {
        screen = Screen.HOME
        query = ""
    }

    fun openTab(t: Tab) {
        tab = t
        categoryId = null
        query = ""
        screen = Screen.BROWSE
        loadTab(t)
    }

    fun openFavorites() {
        screen = Screen.FAVORITES
    }

    fun openSettings() {
        screen = Screen.SETTINGS
    }

    fun selectCategory(id: String?) {
        categoryId = id
    }

    fun retry() = loadTab(tab, force = true)

    fun ensureLoaded(t: Tab) = loadTab(t)

    private fun loadTab(t: Tab, force: Boolean = false) {
        val r = source ?: return
        if (!force && (data.containsKey(t) || loadingTabs[t] == true)) return
        viewModelScope.launch {
            loadingTabs[t] = true
            failedTabs[t] = false
            try {
                val (c, e) = coroutineScope {
                    val a = async { r.categories(t) }
                    val b = async { r.entries(t) }
                    a.await() to b.await()
                }
                cats[t] = c
                data[t] = e
            } catch (e: Exception) {
                failedTabs[t] = true
            }
            loadingTabs[t] = false
        }
    }

    // ---------- Playback ----------

    /** Plays [e]. For live TV, [queue] is the channel list that next/previous walk through. */
    fun play(t: Tab, e: Entry, queue: List<Entry> = listOf(e)) {
        val s = source ?: return
        addRecent(t, e)
        if (t == Tab.SERIES && s.hasSeriesDetail) {
            openSeries(e)
            return
        }
        val q = if (queue.isEmpty()) listOf(e) else queue
        val idx = q.indexOfFirst { it.sameAs(e) }.coerceAtLeast(0)
        playing = PlayRequest(
            title = e.name,
            url = s.playUrl(t, e),
            live = t == Tab.LIVE,
            queue = if (t == Tab.LIVE) q else emptyList(),
            index = idx,
        )
    }

    /** Live TV: move to the next (+1) or previous (-1) channel in the queue. */
    fun zap(delta: Int) {
        val p = playing ?: return
        val s = source ?: return
        if (!p.live || p.queue.size < 2) return
        val i = Math.floorMod(p.index + delta, p.queue.size)
        val e = p.queue[i]
        playing = p.copy(title = e.name, url = s.playUrl(Tab.LIVE, e), index = i)
        addRecent(Tab.LIVE, e)
    }

    fun queueFor(f: Fav): List<Entry> {
        val all = data[f.tab].orEmpty()
        return if (f.tab == Tab.LIVE && all.any { it.sameAs(f.entry) }) all else listOf(f.entry)
    }

    private fun openSeries(e: Entry) {
        val r = source ?: return
        if (seriesLoading) return
        viewModelScope.launch {
            seriesLoading = true
            try {
                seriesDetail = r.seriesInfo(e)
            } catch (ex: Exception) {
                message = R.string.error_series
            }
            seriesLoading = false
        }
    }

    fun closeSeries() {
        seriesDetail = null
    }

    fun playEpisode(ep: Episode) {
        val r = source ?: return
        val detail = seriesDetail ?: return
        playing = PlayRequest(
            title = "${detail.name} · S${ep.season}E${ep.number}",
            url = r.episodeUrl(ep),
            live = false,
        )
    }

    // ---------- Favourites / recents ----------

    fun isFav(t: Tab, e: Entry) = favorites.any { it.tab == t && it.entry.sameAs(e) }

    fun toggleFav(t: Tab, e: Entry) {
        val i = favorites.indexOfFirst { it.tab == t && it.entry.sameAs(e) }
        if (i >= 0) favorites.removeAt(i) else favorites.add(0, Fav(t, e))
        prefs.saveFavs(favorites.toList())
    }

    private fun addRecent(t: Tab, e: Entry) {
        recents.removeAll { it.tab == t && it.entry.sameAs(e) }
        recents.add(0, Fav(t, e))
        while (recents.size > 20) recents.removeAt(recents.size - 1)
        prefs.saveRecents(recents.toList())
    }
}
