# Keep Gson models used by Retrofit
-keep class com.xplayer.app.data.** { *; }
