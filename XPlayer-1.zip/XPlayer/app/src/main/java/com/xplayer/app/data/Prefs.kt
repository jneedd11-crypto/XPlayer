package com.xplayer.app.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("xplayer", Context.MODE_PRIVATE)

    fun save(c: Credentials) {
        sp.edit()
            .putString("server", c.server)
            .putString("user", c.username)
            .putString("pass", c.password)
            .apply()
    }

    fun load(): Credentials? {
        val s = sp.getString("server", null) ?: return null
        val u = sp.getString("user", null) ?: return null
        val p = sp.getString("pass", null) ?: return null
        return Credentials(s, u, p)
    }

    fun clear() = sp.edit().clear().apply()
}
