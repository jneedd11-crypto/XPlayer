package com.xplayer.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7C5CFF),
    onPrimary = Color.White,
    secondary = Color(0xFF29D3C0),
    background = Color(0xFF0E0F14),
    onBackground = Color(0xFFECEDF3),
    surface = Color(0xFF171923),
    onSurface = Color(0xFFECEDF3),
    surfaceVariant = Color(0xFF222534),
    onSurfaceVariant = Color(0xFFB4B7C7),
    error = Color(0xFFFF6B6B),
)

@Composable
fun XTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
