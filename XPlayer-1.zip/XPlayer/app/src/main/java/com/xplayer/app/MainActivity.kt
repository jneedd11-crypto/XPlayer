package com.xplayer.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.xplayer.app.ui.HomeScreen
import com.xplayer.app.ui.LoginScreen
import com.xplayer.app.ui.PlayerScreen
import com.xplayer.app.ui.SeriesScreen
import com.xplayer.app.ui.XTheme

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            XTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(vm)
                }
            }
        }
    }
}

@Composable
private fun App(vm: MainViewModel) {
    val playing = vm.playing
    val series = vm.seriesDetail
    when {
        vm.repo == null -> LoginScreen(vm)
        playing != null -> PlayerScreen(playing, onClose = { vm.playing = null })
        series != null -> SeriesScreen(vm, series)
        else -> HomeScreen(vm)
    }
}
