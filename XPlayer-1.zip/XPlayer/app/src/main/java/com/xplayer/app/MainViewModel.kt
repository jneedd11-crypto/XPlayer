package com.xplayer.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xplayer.app.data.Category
import com.xplayer.app.data.Credentials
import com.xplayer.app.data.Entry
import com.xplayer.app.data.Episode
import com.xplayer.app.data.PlayRequest
import com.xplayer.app.data.Prefs
import com.xplayer.app.data.SeriesDetail
import com.xplayer.app.data.Tab
import com.xplayer.app.data.XtreamRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)

    var repo by mutableStateOf<XtreamRepository?>(null)
        private set

    // Login
    var loginLoading by mutableStateOf(false)
        private set
    var loginError by mutableStateOf<Int?>(null)
        private set

    // Home
    var tab by mutableStateOf(Tab.LIVE)
        private set
    var categoryId by mutableStateOf<String?>(null)
        private set
    var query by mutableStateOf("")

    private val cats = mutableStateMapOf<Tab, List<Category>>()
    private val data = mutableStateMapOf<Tab, List<Entry>>()
    private val loadingTabs = mutableStateMapOf<Tab, Boolean>()
    private val failedTabs = mutableStateMapOf<Tab, Boolean>()

    val categories: List<Category> get() = cats[tab].orEmpty()
    val allItems: List<Entry> get() = data[tab].orEmpty()
    val loading: Boolean get() = loadingTabs[tab] == true
    val failed: Boolean get() = failedTabs[tab] == true

    // Playback / series
    var playing by mutableStateOf<PlayRequest?>(null)
    var seriesDetail by mutableStateOf<SeriesDetail?>(null)
        private set
    var seriesLoading by mutableStateOf(false)
        private set
    var message by mutableStateOf<Int?>(null)

    init {
        prefs.load()?.let { openSession(it) }
    }

    fun login(server: String, user: String, pass: String) {
        if (server.isBlank() || user.isBlank() || pass.isBlank()) {
            loginError = R.string.error_fields
            return
        }
        val cred = Credentials(server.trim(), user.trim(), pass.trim())
        viewModelScope.launch {
            loginLoading = true
            loginError = null
            try {
                val res = XtreamRepository(cred).authenticate()
                if (res.user_info?.auth == "1") {
                    prefs.save(cred)
                    openSession(cred)
                } else {
                    loginError = R.string.error_auth
                }
            } catch (e: Exception) {
                loginError = R.string.error_connect
            }
            loginLoading = false
        }
    }

    private fun openSession(cred: Credentials) {
        repo = XtreamRepository(cred)
        loadTab(tab)
    }

    fun logout() {
        prefs.clear()
        repo = null
        cats.clear()
        data.clear()
        loadingTabs.clear()
        failedTabs.clear()
        playing = null
        seriesDetail = null
        tab = Tab.LIVE
        categoryId = null
        query = ""
    }

    fun selectTab(t: Tab) {
        tab = t
        categoryId = null
        query = ""
        loadTab(t)
    }

    fun selectCategory(id: String?) {
        categoryId = id
    }

    fun retry() = loadTab(tab, force = true)

    private fun loadTab(t: Tab, force: Boolean = false) {
        val r = repo ?: return
        if (!force && (data.containsKey(t) || loadingTabs[t] == true)) return
        viewModelScope.launch {
            loadingTabs[t] = true
            failedTabs[t] = false
            try {
                val (c, e) = coroutineScope {
                    val a = async { r.categories(t) }
                    val b = async { r.entries(t) }
                    a.await() to b.await()
                }
                cats[t] = c
                data[t] = e
            } catch (e: Exception) {
                failedTabs[t] = true
            }
            loadingTabs[t] = false
        }
    }

    fun onEntryClick(e: Entry) {
        val r = repo ?: return
        when (tab) {
            Tab.LIVE -> playing = PlayRequest(e.name, r.liveUrl(e.id))
            Tab.MOVIES -> playing = PlayRequest(e.name, r.movieUrl(e.id, e.ext))
            Tab.SERIES -> openSeries(e)
        }
    }

    private fun openSeries(e: Entry) {
        val r = repo ?: return
        if (seriesLoading) return
        viewModelScope.launch {
            seriesLoading = true
            try {
                seriesDetail = r.seriesInfo(e)
            } catch (ex: Exception) {
                message = R.string.error_series
            }
            seriesLoading = false
        }
    }

    fun closeSeries() {
        seriesDetail = null
    }

    fun playEpisode(ep: Episode) {
        val r = repo ?: return
        val detail = seriesDetail ?: return
        playing = PlayRequest(
            title = "${detail.name} · S${ep.season}E${ep.number}",
            url = r.episodeUrl(ep),
        )
    }
}
