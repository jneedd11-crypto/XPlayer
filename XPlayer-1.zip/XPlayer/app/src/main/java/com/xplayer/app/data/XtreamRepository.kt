package com.xplayer.app.data

import android.net.Uri
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class XtreamRepository(private val cred: Credentials) {

    private val base: String = normalizeServer(cred.server)

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            chain.proceed(
                chain.request().newBuilder().header("User-Agent", "XPlayer/1.0").build()
            )
        }
        .build()

    private val api: XtreamApi = Retrofit.Builder()
        .baseUrl(base)
        .client(http)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(XtreamApi::class.java)

    private val u get() = cred.username
    private val p get() = cred.password

    suspend fun authenticate(): AuthResponse = api.auth(u, p)

    suspend fun categories(tab: Tab): List<Category> {
        val action = when (tab) {
            Tab.LIVE -> "get_live_categories"
            Tab.MOVIES -> "get_vod_categories"
            Tab.SERIES -> "get_series_categories"
        }
        return api.categories(u, p, action).filter { !it.category_id.isNullOrBlank() }
    }

    suspend fun entries(tab: Tab): List<Entry> = when (tab) {
        Tab.LIVE -> api.live(u, p, "get_live_streams").map {
            Entry(it.stream_id, it.name.orEmpty(), it.stream_icon, it.category_id, null, null)
        }
        Tab.MOVIES -> api.vod(u, p, "get_vod_streams").map {
            Entry(it.stream_id, it.name.orEmpty(), it.stream_icon, it.category_id, it.container_extension, it.rating)
        }
        Tab.SERIES -> api.series(u, p, "get_series").map {
            Entry(it.series_id, it.name.orEmpty(), it.cover, it.category_id, null, it.rating)
        }
    }

    suspend fun seriesInfo(entry: Entry): SeriesDetail {
        val root = api.seriesInfo(u, p, "get_series_info", entry.id)
        val info = root.obj("info")
        val list = mutableListOf<Episode>()

        fun addAll(season: Int?, arr: JsonArray) {
            arr.forEach { el ->
                if (!el.isJsonObject) return@forEach
                val o = el.asJsonObject
                val id = o.str("id")
                if (id.isEmpty()) return@forEach
                list += Episode(
                    id = id,
                    title = o.str("title").ifEmpty { "Episode" },
                    season = season ?: o.str("season").toIntOrNull() ?: 1,
                    number = o.str("episode_num").toIntOrNull() ?: 0,
                    ext = o.str("container_extension").ifEmpty { "mp4" },
                    image = o.obj("info")?.str("movie_image")?.ifEmpty { null },
                )
            }
        }

        val eps = root.get("episodes")
        when {
            eps == null || eps.isJsonNull -> Unit
            eps.isJsonObject -> eps.asJsonObject.entrySet().forEach { (key, value) ->
                if (value.isJsonArray) addAll(key.toIntOrNull(), value.asJsonArray)
            }
            eps.isJsonArray -> eps.asJsonArray.forEach { value ->
                if (value.isJsonArray) addAll(null, value.asJsonArray)
            }
        }

        return SeriesDetail(
            name = entry.name,
            cover = info?.str("cover")?.ifEmpty { null } ?: entry.image,
            plot = info?.str("plot")?.ifEmpty { null },
            episodes = list.sortedWith(compareBy({ it.season }, { it.number })),
        )
    }

    // ---- Stream URLs ----

    private fun enc(s: String) = Uri.encode(s)

    fun liveUrl(id: Int) = "${base}live/${enc(u)}/${enc(p)}/$id.m3u8"

    fun movieUrl(id: Int, ext: String?) =
        "${base}movie/${enc(u)}/${enc(p)}/$id.${ext?.takeIf { it.isNotBlank() } ?: "mp4"}"

    fun episodeUrl(ep: Episode) = "${base}series/${enc(u)}/${enc(p)}/${ep.id}.${ep.ext}"

    companion object {
        fun normalizeServer(raw: String): String {
            var s = raw.trim()
            if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "http://$s"
            return s.trimEnd('/') + "/"
        }
    }
}

private fun JsonObject.str(key: String): String =
    get(key)?.takeIf { it.isJsonPrimitive }?.asString.orEmpty()

private fun JsonObject.obj(key: String): JsonObject? =
    get(key)?.takeIf { it.isJsonObject }?.asJsonObject
