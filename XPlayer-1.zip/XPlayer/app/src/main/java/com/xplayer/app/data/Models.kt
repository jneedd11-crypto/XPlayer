package com.xplayer.app.data

// ---- Raw API models (Gson) ----

data class UserInfo(val auth: String?, val status: String?)

data class AuthResponse(val user_info: UserInfo?)

data class Category(val category_id: String?, val category_name: String?)

data class LiveStream(
    val stream_id: Int,
    val name: String?,
    val stream_icon: String?,
    val category_id: String?,
)

data class VodStream(
    val stream_id: Int,
    val name: String?,
    val stream_icon: String?,
    val category_id: String?,
    val rating: String?,
    val container_extension: String?,
)

data class SeriesItem(
    val series_id: Int,
    val name: String?,
    val cover: String?,
    val category_id: String?,
    val rating: String?,
)

// ---- App models ----

enum class Tab { LIVE, MOVIES, SERIES }

/** A unified row for channels, movies and series. */
data class Entry(
    val id: Int,
    val name: String,
    val image: String?,
    val categoryId: String?,
    val ext: String?,
    val rating: String?,
)

data class Episode(
    val id: String,
    val title: String,
    val season: Int,
    val number: Int,
    val ext: String,
    val image: String?,
)

data class SeriesDetail(
    val name: String,
    val cover: String?,
    val plot: String?,
    val episodes: List<Episode>,
)

data class PlayRequest(val title: String, val url: String)

data class Credentials(val server: String, val username: String, val password: String)
